## Модуль для работы с Yandex Translate API
<br>
!!! Библиотека активно редактируется (возможны сильные изменеия)
<br><br>
Для работы необходимо просто импортировать и создать объект переводчика<br>

`from translate.yandex_transalte import Translate`

`translate = Translate()`

`translated_text = translate.translate("Hello", "en", "ja")`

`print(translated_text)`
